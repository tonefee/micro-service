package com.codingapi.txlcn.tc.coprelog;

import com.codingapi.txlcn.tc.MiniConfiguration;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Description:
 * Date: 19-2-12 上午10:06
 *
 * @author ujued
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MiniConfiguration.class)
public class TxcLogTest {
}
