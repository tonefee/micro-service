package com.codingapi.txlcn.common.util.id;

/**
 * Description:
 * Date: 19-2-14 下午4:41
 *
 * @author ujued
 */
public interface ModIdProvider {
    /**
     * get mod id
     *
     * @return id
     */
    String modId();
}
